package ca.sheridancollege.sin14089;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A1SukhmanmeetSinghApplication {

	public static void main(String[] args) {
		SpringApplication.run(A1SukhmanmeetSinghApplication.class, args);
	}

}
