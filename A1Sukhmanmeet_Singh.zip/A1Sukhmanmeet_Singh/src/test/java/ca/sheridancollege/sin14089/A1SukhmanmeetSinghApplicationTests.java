package ca.sheridancollege.sin14089;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A1SukhmanmeetSinghApplicationTests {

	@Test
	void contextLoads() {
	}

}
